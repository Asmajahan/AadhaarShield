from flask import Flask, request, jsonify, render_template, send_file
import easyocr
import re
import cv2
import os
import numpy as np
from io import BytesIO

# Initialize Flask app
app = Flask(__name__)

# Initialize EasyOCR reader
reader = easyocr.Reader(['en'], gpu=False)

# Path to save masked images
output_dir = r"C:\Users\asmaj\Downloads\Aadhaar card Sample\Masked_Aadhar"
os.makedirs(output_dir, exist_ok=True)

# Define the route for the homepage
@app.route('/')
def home():
    return render_template('index.html')

# Define the route for processing the uploaded image
@app.route('/process_image', methods=['POST'])
def process_image():
    # Get the image file from the request
    if 'image' not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    file = request.files['image']
    
    # Read the image into OpenCV format
    npimg = np.frombuffer(file.read(), np.uint8)
    image = cv2.imdecode(npimg, cv2.IMREAD_COLOR)

    # Read text from the image using EasyOCR
    result = reader.readtext(image)

    # Create a copy of the image for masking
    image_masking = image.copy()

    # Loop through the result to find Aadhaar numbers
    for i in result:
        # Define the pattern for Aadhaar number
        aadhar_pattern = r'\b\d{4}\s?\d{4}\s?\d{4}\b'

        # Find all matches in the text
        found_matches = re.findall(aadhar_pattern, i[1])
        if found_matches:
            for match in found_matches:
                bounding_box = i[0]

                # Define the color and thickness of the mask
                mask_color = (0, 0, 0)  # Black mask
                mask_thickness = -1     # Fill the rectangle

                # Calculate the width for the first 8 digits
                width = bounding_box[1][0] - bounding_box[0][0]
                mask_width = int(width * 0.67)  # Adjust this factor if needed

                # Create a new bounding box to cover the first 8 digits
                x1, y1 = bounding_box[0]
                x2, y2 = x1 + mask_width, bounding_box[2][1]

                # Draw the mask
                cv2.rectangle(image_masking, (x1, y1), (x2, y2), mask_color, mask_thickness)

    # Convert masked image to a format that can be displayed
    _, buffer = cv2.imencode('.png', image_masking)
    img_io = BytesIO(buffer)
    print("Done with the masking")
    # Return the masked image
    return send_file(img_io, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)
    